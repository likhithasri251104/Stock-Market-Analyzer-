
import java.util.*;

public class StockAnalyzer {
    public static String analyzeTrend(List<Double> prices) {
        if (prices.size() < 2) return "Insufficient data";
        double trend = prices.get(prices.size() - 1) - prices.get(prices.size() - 2);
        return trend > 0 ? "Upward trend" : trend < 0 ? "Downward trend" : "Stable";
    }
}
