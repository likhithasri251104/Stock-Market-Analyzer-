
public class Main {
    public static void main(String[] args) {
        DashboardUI.main(args);
    }
}
