
import java.io.*;
import java.net.*;
import org.json.JSONObject;

public class StockAPIClient {
    private static final String API_KEY = "YOUR_API_KEY";
    private static final String BASE_URL = "https://finnhub.io/api/v1/quote?symbol=%s&token=" + API_KEY;

    public static double getLivePrice(String symbol) throws Exception {
        URL url = new URL(String.format(BASE_URL, symbol));
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String response = br.readLine();
        JSONObject json = new JSONObject(response);
        return json.getDouble("c"); // current price
    }
}
