
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.util.*;

public class DashboardUI extends Application {
    private List<Double> priceHistory = new ArrayList<>();
    private LineChart<String, Number> lineChart;

    @Override
    public void start(Stage stage) {
        stage.setTitle("Real-Time Stock Dashboard");

        TextField symbolInput = new TextField("AAPL");
        Button fetchButton = new Button("Fetch Price");
        Label trendLabel = new Label("Trend: ");
        Label creditLabel = new Label("Created by Likhitha Sri");

        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        lineChart = new LineChart<>(xAxis, yAxis);
        lineChart.setTitle("Stock Prices");

        fetchButton.setOnAction(e -> {
            try {
                String symbol = symbolInput.getText();
                double price = StockAPIClient.getLivePrice(symbol);
                priceHistory.add(price);
                trendLabel.setText("Trend: " + StockAnalyzer.analyzeTrend(priceHistory));
                updateChart(symbol);
                if (priceHistory.size() > 1) {
                    double diff = price - priceHistory.get(priceHistory.size() - 2);
                    if (Math.abs(diff) > 5.0) {
                        Notifier.showNotification("Price Alert", symbol + " changed by " + diff);
                    }
                }
            } catch (Exception ex) {
                trendLabel.setText("Error fetching data.");
            }
        });

        VBox root = new VBox(10, symbolInput, fetchButton, trendLabel, lineChart, creditLabel);
        root.setStyle("-fx-padding: 15;");
        creditLabel.setStyle("-fx-font-style: italic; -fx-alignment: center;");

        stage.setScene(new Scene(root, 600, 450));
        stage.show();
    }

    private void updateChart(String symbol) {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        for (int i = 0; i < priceHistory.size(); i++) {
            series.getData().add(new XYChart.Data<>(String.valueOf(i), priceHistory.get(i)));
        }
        lineChart.getData().clear();
        series.setName(symbol);
        lineChart.getData().add(series);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
